MANEUVER 1.0.0
Puppetmaster maneuver tracker for HorizonXI
Author: Plate

OVERVIEW
Maneuver tracks your active Puppetmaster Maneuvers and the server-reported overload chance associated with each element. It only accepts maneuver actions from the local player and automatically shows/hides rows as Maneuvers become active or expire.

REQUIREMENTS
- HorizonXI
- Ashita v4
- Puppetmaster main job by default

INSTALLATION
1. Extract the included "maneuver" folder into your Ashita addons folder.
2. In game, run:
   /addon load maneuver
3. To reload after updating:
   /addon reload maneuver

BASIC COMMANDS
/maneuver                 Toggle the HUD.
/maneuver show            Show the HUD.
/maneuver hide            Hide the HUD.
/maneuver clear           Clear current tracked Maneuver data.
/maneuver help            Show command help in chat.
/maneuver reset           Reset settings and HUD position/size.
/maneuver save            Save settings.
/maneuver reload          Reload settings from disk.
/maneuver debug           Toggle troubleshooting information.

SETTINGS COMMANDS
/maneuver timer on|off
    Show or hide the remaining Maneuver timer.

/maneuver autohide on|off
    When on, the HUD is completely hidden when no Maneuvers are active.

/maneuver headers on|off
    Show or hide the column headers.

/maneuver background on|off
    Show or hide the solid background behind each active row.

/maneuver opacity 0-100
    Set the active-row background opacity. Example: /maneuver opacity 80

/maneuver puponly on|off
    When on (default), tracking/rendering is restricted to Puppetmaster main job.

DEFAULTS
- Auto-hide: ON
- Timer: ON
- Headers: ON
- Solid row background: ON
- Row opacity: 94%
- PUP-only mode: ON

HOW IT WORKS
- Uses the current player's dynamic server ID; no character name or ID editing is needed.
- Confirms local Maneuver job abilities from incoming action packets.
- Matches those actions to HorizonXI's Maneuver overload text.
- Supports Fire, Ice, Wind, Earth, Thunder, Water, Light, and Dark Maneuver.
- Supports active x1/x2/x3 Maneuver stacks.
- The timer is removed when the Maneuver expires, and the entire row disappears immediately after the final stack expires.
- 30% actual overload chance is represented as 100% on the visual gauge.

COMPATIBILITY ALIASES
/overload and /pupoverload are retained as command aliases for users upgrading from older development builds. New users should use /maneuver.

TROUBLESHOOTING
- If the HUD is off-screen or oddly sized, use /maneuver reset.
- If icons fail to appear, confirm the assets folder is present beside maneuver.lua.
- Use /maneuver debug when reporting tracking problems.

PUBLIC RELEASE NOTES
This 1.0.0 build adds persistent Ashita settings, public-friendly commands, reset/help functions, PUP-only mode, safer defaults, and user-configurable HUD behavior while preserving the tested HorizonXI packet/log matching logic.
